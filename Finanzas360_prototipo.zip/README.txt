FINANZAS 360° — Prototipo funcional

Contenido:
- index.html: aplicación web móvil en un solo archivo.
- Funciones: navegación, educación financiera, registro de gastos, metas y calculadora de interés compuesto.
- Secciones: sistema financiero y fintech.

Uso:
1. Abre index.html en un navegador.
2. En celular puedes abrirlo desde el navegador y agregarlo a la pantalla de inicio.
3. Es un prototipo educativo; no conecta con bancos ni procesa dinero real.
