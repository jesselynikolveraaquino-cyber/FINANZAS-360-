FINANZAS 360° — Nueva versión
================================
Archivo principal: index.html

Para actualizar GitHub:
1. En tu repositorio abre index.html.
2. Pulsa Editar (icono de lápiz) o reemplaza el archivo.
3. Sustituye todo el contenido por el de esta nueva versión.
4. Confirma los cambios en la rama principal.
5. GitHub Pages actualizará la web automáticamente.

Funciones incluidas:
- Inicio con panel financiero.
- Registro de gastos por categoría y eliminación de movimientos.
- Metas de ahorro.
- Calculadora de interés compuesto.
- Microlecciones sobre cultura financiera.
- Mini quiz con puntuación.
- Sistema financiero y fintech.
- Guardado local en el dispositivo mediante localStorage.
- Diseño responsive para celular.
